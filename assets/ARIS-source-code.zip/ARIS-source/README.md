# ARIS — Authenticated Randomness Infrastructure Service (MOKE TRNG)

## Overview

ARIS is a hardware true random number generator that turns physical entropy from a **Magneto-Optic Kerr Effect (MOKE)** optical bench into cryptographically signed, statistically validated random data. A helium-neon laser is directed at a magnetic thin film held near its coercive point, where competing magnetic states are energetically almost equal and domain switching is genuinely stochastic. The resulting polarization rotation is converted to an intensity modulation, recovered by an SR865A lock-in amplifier, debiased, expanded, screened against NIST SP 800-22, and committed to a hash-chained audit log. Every accepted block carries an Ed25519 signature, so a third party holding only the public key can confirm that a given block came from this device, in this order, at this time.

This repository holds the software half of the system: the entropy pipeline, the record format, the signing and verification code, and the demo that builds and checks a full chain. It was built as a senior design project in the Department of Electrical and Computer Engineering at the University of Miami, Spring 2026, by **Maxwell Cosenza**, **Joel Eyison**, and **Johnathon L'Amoreaux**, advised by **Dr. Stephen Murrell** and **Dr. Sakhrat Khizroev**.

---

## Features

- **Physical entropy source.** Randomness comes from quantum magnetic domain switching in a thin film, not from a software PRNG or an OS entropy pool.
- **Von Neumann debiasing.** Raw comparator bits are debiased before any conditioning, removing the bias of the underlying physical process.
- **SHA-256 conditioning.** Debiased bits are expanded into 256-bit blocks, giving uniform output blocks at a known length.
- **Inline NIST screening.** Monobit and runs tests gate every block, so a block that fails basic randomness never reaches the chain.
- **Full NIST SP 800-22 validation.** A separate driver runs the complete 15-test suite over the combined dataset.
- **Tamper-evident audit log.** Each record stores the SHA-256 of the previous record, so any edit to a past entry cascades into a hash mismatch.
- **Ed25519 signatures.** Records are signed over a canonical JSON encoding, giving 128-bit security with 32-byte keys and 64-byte signatures.
- **Independent verifier.** Chain integrity, signature validity, and timestamp precedence can all be checked with the public key alone.

---

## How It Works

### Optical Entropy Source

A linearly polarized helium-neon laser running under 5 mW acts as the optical carrier. It reflects off a magnetic thin film biased near its coercive point. A quarter-wave plate and a high-extinction Glan laser polarizer convert the small Kerr rotation into an intensity modulation, and a mechanical chopper modulates the beam at a fixed reference frequency so the lock-in amplifier can reject everything outside that band. Balanced photodiodes feed the SR865A, which performs phase-sensitive detection at the chopper reference and exports R and Theta columns as CSV.

### Bit Extraction and Debiasing

`process_entropy.py` ingests the SR865A CSV, applies a linear detrend to remove slow drift in the optical path, and runs the `vn_sha_r` extraction: Von Neumann debiasing over the comparator bit stream, followed by SHA-256 expansion into 256-bit blocks. Detrending matters because any thermal or mechanical drift in the bench shows up as a low-frequency bias that would otherwise survive into the output.

### Statistical Screening

Each candidate block is screened with the NIST SP 800-22 monobit and runs tests before it is accepted. Blocks that fail are dropped rather than corrected. `nist_full_suite.py` runs the complete 15-test suite across the accumulated bit stream for end-of-run validation, and reports how many bits were collected before it starts, since several tests are only meaningful above roughly one million bits.

### Record Format and Hash Chain

`record_format.py` defines one record: version, block ID, device ID, start and end sequence numbers, UTC timestamp, bit length, the SHA-256 of the block, the SHA-256 of the previous record, the NIST results, and the entropy estimates. The first record in a chain uses a genesis previous-hash of 64 zeros. Records are serialized with `canonical_json_bytes`, which sorts keys and strips whitespace, so the same record always produces identical bytes to sign and to verify.

### Signing and Verification

`signing.py` generates an Ed25519 keypair, saves and loads it as PEM, and signs the canonical encoding of each record. `sign_demo.py` and `multi_block_demo.py` build a chain and then verify it end to end: every signature checks against the public key, every record's previous-hash matches its predecessor, and timestamps increase monotonically.

### Results

The production run produced a tamper-evident chain of **11,151 blocks**. All 15 NIST SP 800-22 tests pass on the combined **2.8-million-bit** dataset. A REST API serves blocks to three demonstrations: an authenticated blackjack game, a Monte Carlo portfolio risk simulation, and a fair audit-sampling tool.

---

## Technologies Used

- **Language:** Python 3
- **Libraries:** `cryptography` (Ed25519, PEM serialization), NumPy, `hashlib`
- **Instrumentation:** Stanford Research SR865A lock-in amplifier, balanced photodiodes (Thorlabs DET10A and DET36A, Hinds DET-200), mechanical optical chopper, helium-neon laser, Glan laser polarizer, quarter-wave plate
- **Validation:** NIST SP 800-22 Statistical Test Suite
- **Concepts:** True random number generation, Von Neumann debiasing, hash chaining, digital signatures, lock-in detection

---

## Getting Started

### Prerequisites

- Python 3.10 or newer
- `pip install cryptography numpy`
- An SR865A CSV export with R and Theta columns, or the included chain demo if you only want to verify
- The NIST SP 800-22 Statistical Test Suite, built under `sts_suite/sts`, for the full validation run

### Installation & Execution

1. Clone the repository and change into the `Senior Design` directory.
2. Generate a keypair with the helpers in `signing.py`. The repository ships a development public key only; no private key is distributed, so generate your own before signing anything.
3. Run `python process_entropy.py` against an SR865A CSV to extract, screen, and build a signed record.
4. Run `python multi_block_demo.py` to build a multi-block chain and verify it end to end.
5. Run `python nist_full_suite.py` to extract bits and hand the stream to the full NIST suite.
6. Run `python test_process_entropy.py` for the pipeline unit tests.

---

## Repository Structure

- `process_entropy.py` — CSV ingest, detrending, bit extraction, inline NIST screening, signed record construction
- `record_format.py` — record schema, genesis hash, canonical JSON encoding
- `signing.py` — Ed25519 keypair generation, PEM load and save, sign and verify
- `sign_demo.py` — single-record signing and chain verification demo
- `multi_block_demo.py` — multi-block chain construction and verification
- `nist_full_suite.py` — driver for the complete NIST SP 800-22 suite
- `test_process_entropy.py` — unit tests for the entropy pipeline
- `aris_chain_demo.json` — a 220-record signed chain, published as a demonstration subset of the full 11,151-block run
- `aris_dev_public.pem` — development public key, for verifying the demo chain only

---

## Languages

100% Python.
