from typing import Dict, Any, List, Tuple

from record_format import (
    make_record_without_signature,
    compute_record_hash,
    verify_chain,
    GENESIS_PREV_HASH,
)
from signing import (
    load_private_key_pem,
    load_public_key_pem,
    sign_record,
    verify_signed_record,
)


def verify_signed_chain(records: List[Dict[str, Any]], pub) -> Tuple[bool, str]:
    # 1) Verify signatures first (authenticity)
    for i, r in enumerate(records):
        if not verify_signed_record(pub, r):
            return False, f"Bad signature at index {i}"

    # 2) Verify hash chain using records WITHOUT signatures (integrity)
    stripped = []
    for r in records:
        r_wo = dict(r)
        r_wo.pop("signature", None)
        stripped.append(r_wo)

    ok, msg = verify_chain(stripped)
    return ok, msg


def main():
    priv = load_private_key_pem("aris_dev_private.pem")
    pub = load_public_key_pem("aris_dev_public.pem")

    # Record 1 (genesis)
    r1 = make_record_without_signature(
        version=1,
        block_id="block-001",
        device_id="ARIS-FPGA-01",
        seq_start=0,
        seq_end=1023,
        timestamp_utc="2026-01-13T00:00:00Z",
        bit_length=8192,
        block_hash_sha256="aa"*32,
        prev_record_hash_sha256=GENESIS_PREV_HASH,
        nist={"alpha": 0.10, "tests": {}, "all_pass": True},
        entropy={"min_entropy_est": None},
    )
    h1 = compute_record_hash(r1)

    # Record 2 points to record 1
    r2 = make_record_without_signature(
        version=1,
        block_id="block-002",
        device_id="ARIS-FPGA-01",
        seq_start=1024,
        seq_end=2047,
        timestamp_utc="2026-01-13T00:01:00Z",
        bit_length=8192,
        block_hash_sha256="bb"*32,
        prev_record_hash_sha256=h1,
        nist={"alpha": 0.10, "tests": {}, "all_pass": True},
        entropy={"min_entropy_est": None},
    )

    s1 = sign_record(priv, r1)
    s2 = sign_record(priv, r2)

    chain = [s1, s2]

    ok, msg = verify_signed_chain(chain, pub)
    print("Signed chain valid:", ok, msg)

    # Tamper with linkage (break the chain, but keep signatures valid individually)
    broken = [dict(s1), dict(s2)]
    broken[1]["signature"] = broken[1]["signature"]  # unchanged signature
    broken[1]["prev_record_hash_sha256"] = "ff" * 32  # breaks link
    ok2, msg2 = verify_signed_chain(broken, pub)
    print("Signed chain valid after link tamper:", ok2, msg2)


if __name__ == "__main__":
    main()
