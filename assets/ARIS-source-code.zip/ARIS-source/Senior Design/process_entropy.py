#process_entropy.py
#front-end of the aris entropy pipeline.
#reads sr865 csv, detrends, extracts bits, runs nist tests, and builds signed record.

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import struct
import sys
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

#import existing aris modules
from record_format import GENESIS_PREV_HASH, make_record_without_signature
from signing import load_private_key_pem, sign_record

#constants
DEVICE_ID = "ARIS-SR865-01"
VERSION = 1


#step 1 — csv ingest

#returns a named column from an sr865 csv as a list of floats
def read_column_from_csv(csv_path: str, col: str = "R") -> List[float]:
    values: List[float] = []
    with open(csv_path, newline="") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise ValueError("CSV file appears to be empty.")
        clean_fields = [f.strip().strip('"') for f in reader.fieldnames]
        if col not in clean_fields:
            raise ValueError(
                f"Column '{col}' not found. Available: {clean_fields}"
            )
        col_index = clean_fields.index(col)
        original_key = reader.fieldnames[col_index]

        for row in reader:
            raw = row[original_key].strip().strip('"')
            values.append(float(raw))

    if not values:
        raise ValueError("No data rows found in CSV.")
    return values


# Keep old name as alias for backward compatibility
def read_theta_from_csv(csv_path: str, theta_col: str = "Theta") -> List[float]:
    return read_column_from_csv(csv_path, col=theta_col)


#step 2 — linear detrend

#subtracts the best-fit line to remove dc bias drift
def linear_detrend(signal: List[float]) -> np.ndarray:
    arr = np.asarray(signal, dtype=float)
    x = np.arange(len(arr), dtype=float)
    # Least-squares fit: coefficients [slope, intercept]
    coeffs = np.polyfit(x, arr, 1)
    trend = np.polyval(coeffs, x)
    return arr - trend


#step 3a — mean-threshold bit extraction (default)

#compares each detrended sample to the mean and emits a raw bit
def extract_threshold_bits(detrended: np.ndarray) -> List[int]:
    mu = float(np.mean(detrended))
    bits: List[int] = []
    for v in detrended:
        val = float(v)
        if val > mu:
            bits.append(1)
        elif val < mu:
            bits.append(0)
        # skip exact ties (extremely rare with float data)
    return bits


#step 3b — transition-event bit extraction (optional)

#emits a raw bit at every sign change in the first difference of theta
def extract_transition_bits(detrended: np.ndarray) -> List[int]:
    diff = np.diff(detrended)          # Δθ[i] = θ[i+1] − θ[i]
    bits: List[int] = []
    for i in range(len(diff) - 1):
        prev_sign = bool(diff[i] >= 0)    # explicit Python bool to avoid numpy issues
        curr_sign = bool(diff[i + 1] >= 0)
        if prev_sign != curr_sign:        # sign change detected
            bits.append(0 if (prev_sign and not curr_sign) else 1)
    return bits


#step 4 — von neumann debiasing

#standard von neumann extractor
def von_neumann_debias(raw_bits: List[int]) -> List[int]:
    debiased: List[int] = []
    for i in range(0, len(raw_bits) - 1, 2):
        a, b = raw_bits[i], raw_bits[i + 1]
        if a != b:
            debiased.append(a)
    return debiased


#step 5 — nist monobit test

#frequency (monobit) test, returns (passed, p_value)
def nist_monobit(bits: List[int], alpha: float) -> Tuple[bool, float]:
    n = len(bits)
    if n == 0:
        return False, 0.0
    s_n = sum(1 if b == 1 else -1 for b in bits)  # ±1 representation
    s_obs = abs(s_n) / math.sqrt(n)
    p_value = math.erfc(s_obs / math.sqrt(2))
    return p_value >= alpha, p_value


#step 6 — nist runs test

#runs test, returns (passed, p_value)
def nist_runs(bits: List[int], alpha: float) -> Tuple[bool, float]:
    n = len(bits)
    if n < 2:
        return False, 0.0

    pi = sum(bits) / n          # proportion of ones

    # Pre-test: if |pi - 0.5| >= 2/sqrt(n), monobit already failed;
    # runs test is not meaningful
    if abs(pi - 0.5) >= (2.0 / math.sqrt(n)):
        return False, 0.0

    # Count runs
    v_n = 1 + sum(1 for i in range(1, n) if bits[i] != bits[i - 1])

    # Expected and variance under H0
    expected = 2 * n * pi * (1 - pi)
    variance = 2 * math.sqrt(2 * n) * pi * (1 - pi)  # = 2*sqrt(2n)*pi*(1-pi)

    # Normal approximation — use erfc
    if variance == 0:
        return False, 0.0
    z = abs(v_n - expected) / variance if variance > 0 else float("inf")
    p_value = math.erfc(z / math.sqrt(2))
    return p_value >= alpha, p_value


#step 7 — pack bits to bytes

#packs bits (msb-first) into a bytes object
def bits_to_bytes(bits: List[int]) -> bytes:
    n_bits = (len(bits) // 8) * 8
    result = bytearray()
    for i in range(0, n_bits, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        result.append(byte)
    return bytes(result)


#step 8 — sha-256 block hash

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


#sha-256 randomness extractor (single-column mode), returns exactly 256 bits
def sha256_extract(raw_bits: List[int]) -> List[int]:
    raw_bytes = bits_to_bytes(raw_bits)
    digest = hashlib.sha256(raw_bytes).digest()
    out: List[int] = []
    for byte in digest:
        for shift in range(7, -1, -1):
            out.append((byte >> shift) & 1)
    return out


#vn-sha-r extractor with hash chaining (default pipeline)
def vn_sha_r_extract(
    det_theta: List[float],
    det_r: List[float],
) -> List[int]:
    mu_theta = float(np.mean(det_theta))
    raw_bits = [1 if v > mu_theta else 0 for v in det_theta if v != mu_theta]

    output: List[int] = []
    prev_digest = b'\x00' * 32          # initial chaining value
    for i in range(0, len(raw_bits) - 1, 2):
        a, b = raw_bits[i], raw_bits[i + 1]
        if a != b:                      # VN accepts this pair
            v_a = float(det_r[i])
            v_b = float(det_r[i + 1])
            pair_bytes = struct.pack(">dd", v_a, v_b)   # 16 bytes
            digest = hashlib.sha256(pair_bytes + prev_digest).digest()
            prev_digest = digest        # chain into next iteration
            for byte in digest:
                for shift in range(7, -1, -1):
                    output.append((byte >> shift) & 1)
    return output


#main public function

#runs the full pipeline and returns a signed aris record, or none if nist fails
def process_csv_to_signed_record(
    csv_path: str,
    private_key_path: str,
    prev_record_hash: str,
    block_id: str,
    device_id: str = DEVICE_ID,
    seq_start: int = 0,
    alpha: float = 0.01,
    method: str = "threshold",
    column: str = "R",
    extract: str = "vn_sha_r",
) -> Optional[Dict[str, Any]]:
    #1. ingest
    if extract == "vn_sha_r":
        #needs both theta (event selector) and r (entropy carrier)
        theta_vals = read_column_from_csv(csv_path, col="Theta")
        r_vals     = read_column_from_csv(csv_path, col="R")
        det_theta  = list(linear_detrend(theta_vals))
        det_r      = list(linear_detrend(r_vals))
        bits = vn_sha_r_extract(det_theta, det_r)
        if len(bits) < 8:
            print("[WARN] Not enough VN-accepted pairs. Try a longer CSV.", file=sys.stderr)
            return None
    else:
        signal    = read_column_from_csv(csv_path, col=column)
        detrended = linear_detrend(signal)

        if method == "threshold":
            raw_bits = extract_threshold_bits(detrended)
        elif method == "transitions":
            raw_bits = extract_transition_bits(detrended)
        else:
            raise ValueError(f"Unknown method '{method}'. Use 'threshold' or 'transitions'.")

        if extract == "sha256":
            if len(raw_bits) < 8:
                print("[WARN] Not enough raw bits for SHA-256 extraction.", file=sys.stderr)
                return None
            bits = sha256_extract(raw_bits)
        elif extract == "von_neumann":
            bits = von_neumann_debias(raw_bits)
            if len(bits) < 8:
                print(f"[WARN] Only {len(bits)} bits after Von Neumann.", file=sys.stderr)
                return None
        else:
            raise ValueError(f"Unknown extract '{extract}'. Use 'vn_sha_r', 'sha256', or 'von_neumann'.")

    #5 & 6. nist tests
    mono_pass, mono_p = nist_monobit(bits, alpha)
    runs_pass, runs_p = nist_runs(bits, alpha)
    all_pass = mono_pass and runs_pass

    nist_dict: Dict[str, Any] = {
        "alpha": alpha,
        "tests": {
            "monobit": {"pass": mono_pass, "p_value": round(mono_p, 6)},
            "runs":    {"pass": runs_pass, "p_value": round(runs_p, 6)},
        },
        "all_pass": all_pass,
    }

    if not all_pass:
        print("[NIST] FAIL — block rejected.", file=sys.stderr)
        print(json.dumps(nist_dict, indent=2), file=sys.stderr)
        return None

    #7. pack & hash
    bit_bytes = bits_to_bytes(bits)
    block_hash = sha256_hex(bit_bytes)
    bit_length = len(bits)
    seq_end = seq_start + bit_length - 1

    #8. build & sign record
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    record_without_sig = make_record_without_signature(
        version=VERSION,
        block_id=block_id,
        device_id=device_id,
        seq_start=seq_start,
        seq_end=seq_end,
        timestamp_utc=timestamp,
        bit_length=bit_length,
        block_hash_sha256=block_hash,
        prev_record_hash_sha256=prev_record_hash,
        nist=nist_dict,
        entropy={"min_entropy_est": None},  #reserved for future shannon/min-h calc
    )

    priv = load_private_key_pem(private_key_path)
    signed = sign_record(priv, record_without_sig)
    return signed


#cli entry point

def _cli() -> None:
    parser = argparse.ArgumentParser(
        description="Process SR865 CSV → SHA-256 extraction → NIST → signed ARIS record"
    )
    parser.add_argument("--csv",   required=True, help="Path to SR865 CSV file")
    parser.add_argument("--priv",  required=True, help="Path to Ed25519 private key PEM")
    parser.add_argument("--alpha", type=float, default=0.01, help="NIST significance level")
    parser.add_argument(
        "--prev-hash",
        default=GENESIS_PREV_HASH,
        help="Previous record hash (default: GENESIS)",
    )
    parser.add_argument("--block-id",  default=None,      help="Block ID (auto-generated if omitted)")
    parser.add_argument("--device-id", default=DEVICE_ID, help="Device identifier")
    parser.add_argument(
        "--column",
        default="R",
        choices=["R", "Theta", "X", "Y"],
        help="CSV column to use as entropy source (default: R)",
    )
    parser.add_argument(
        "--method",
        default="threshold",
        choices=["threshold", "transitions"],
        help="Bit extraction method (default: threshold)",
    )
    parser.add_argument(
        "--extract",
        default="vn_sha_r",
        choices=["vn_sha_r", "sha256", "von_neumann"],
        help="Extraction mode: 'vn_sha_r' (default), 'sha256', or 'von_neumann'",
    )
    args = parser.parse_args()

    block_id = args.block_id or f"block-{uuid.uuid4().hex[:8]}"

    record = process_csv_to_signed_record(
        csv_path=args.csv,
        private_key_path=args.priv,
        prev_record_hash=args.prev_hash,
        block_id=block_id,
        device_id=args.device_id,
        alpha=args.alpha,
        method=args.method,
        column=args.column,
        extract=args.extract,
    )

    if record is None:
        print("NIST: FAIL — no record produced.")
        sys.exit(1)

    print("NIST: PASS")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    _cli()
