import os
import subprocess
import sys

from process_entropy import read_column_from_csv, linear_detrend, vn_sha_r_extract

FILES = [
    os.path.expanduser("~/Downloads/sr865a_data.csv"),
]

#extracts and returns bits from csv files
def collect_bits():
    bits = []
    for f in FILES:
        if not os.path.exists(f):
            print(f"Warning: File not found: {f}")
            continue
        theta = read_column_from_csv(f, "Theta")
        r     = read_column_from_csv(f, "R")
        bits.extend(vn_sha_r_extract(list(linear_detrend(theta)),
                                     list(linear_detrend(r))))
    return bits

if __name__ == "__main__":
    print("Collecting bits via vn_sha_r pipeline...")
    bits = collect_bits()
    n_bits = len(bits)
    print(f"\n====================================================================")
    print(f"          SUCCESS: You currently have {n_bits:,} bits of data!          ")
    print(f"====================================================================\n")
    
    if n_bits == 0:
        print("No bits collected. Please check your data file path.")
        sys.exit(1)
        
    if n_bits < 100000:
        print("Note: The NIST suite ideally requires at least 1,000,000 bits for reliable results.")
        print("At sizes below 100,000 bits, some tests (like Overlapping Template) might fail validly.")
    else:
        print(f"This is a fantastic amount of data. Running the official NIST suite...")
        
    #sets up paths for nist suite directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    sts_dir = os.path.join(script_dir, "sts_suite", "sts")
    
    if not os.path.exists(os.path.join(sts_dir, "assess")):
        print(f"Error: Could not find the compiled NIST suite at {sts_dir}/assess")
        sys.exit(1)
        
    #writes bits to intermediate text file for c executable
    data_file = os.path.join(sts_dir, "data", "pipeline_bits.txt")
    print("\nWriting extracted bits to intermediate ASCII file...")
    with open(data_file, "w") as f:
        f.write("".join(str(b) for b in bits))
        
    print("Starting Official NIST STS computation (C executable)...\n")
    
    #maps nist interactive prompts to standard input
    input_text = f"0\ndata/pipeline_bits.txt\n1\n0\n1\n0\n"
    
    #removes old report if it exists
    report_path = os.path.join(sts_dir, "experiments", "AlgorithmTesting", "finalAnalysisReport.txt")
    if os.path.exists(report_path):
        os.remove(report_path)
    
    try:
        proc = subprocess.run(
            ["./assess", str(n_bits)],
            cwd=sts_dir,
            input=input_text,
            text=True,
            capture_output=True,
            check=False
        )
    except Exception as e:
        print(f"Error running NIST assess executable: {e}")
        sys.exit(1)
    
    if not os.path.exists(report_path):
        print("Error: NIST suite did not produce a report. It probably crashed. Output was:")
        print(proc.stdout)
        print(proc.stderr)
        sys.exit(1)
        
    print("\n=========== OFFICIAL NIST STS REPORT ===========")
    with open(report_path, "r") as f:
        print(f.read())
    print("================================================")
