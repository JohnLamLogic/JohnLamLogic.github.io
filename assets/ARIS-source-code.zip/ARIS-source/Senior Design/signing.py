import base64
from typing import Dict, Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization

from record_format import canonical_json_bytes

#returns tuples of public and private keys, stored in standard format
def generate_keypair_pem() -> tuple[bytes, bytes]:
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key()
    #converting private key into bytes
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    #converting public key into bytes
    pub_pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return priv_pem, pub_pem

#writes bytes into files
def save_pem(path: str, pem_bytes: bytes) -> None:
    with open(path, "wb") as f:
        f.write(pem_bytes)
        
#opens binary file and returns private key object
def load_private_key_pem(path: str) -> Ed25519PrivateKey:
    with open(path, "rb") as f:
        pem = f.read()
    key = serialization.load_pem_private_key(pem, password=None)
    return key

#opens binary file and returns public key object
def load_public_key_pem(path: str) -> Ed25519PublicKey:
    with open(path, "rb") as f:
        pem = f.read()
    key = serialization.load_pem_public_key(pem)
    return key

#takes a private key and a record, fills in signiture field
def sign_record(priv: Ed25519PrivateKey, record_without_signature: Dict[str, Any]) -> Dict[str, Any]:
    msg = canonical_json_bytes(record_without_signature)
    sig_bytes = priv.sign(msg)
    sig_b64 = base64.b64encode(sig_bytes).decode("ascii")

    record_with_signature = dict(record_without_signature)
    record_with_signature["signature"] = {
        "alg": "ed25519",
        "sig_b64": sig_b64,
    }
    return record_with_signature

#takes public key and signed record, returns true if signiture checks out
def verify_signed_record(pub: Ed25519PublicKey, record_with_signature: Dict[str, Any]) -> bool:
    #makes sure its getting a record with signature
    sig_info = record_with_signature.get("signature")
    if not sig_info or "sig_b64" not in sig_info:
        return False
    sig_bytes = base64.b64decode(sig_info["sig_b64"].encode("ascii"))
    #take out signature, check with public key
    record_without_signature = dict(record_with_signature)
    record_without_signature.pop("signature", None)
    msg = canonical_json_bytes(record_without_signature)
    try:
        pub.verify(sig_bytes, msg)
        return True
    except Exception:
        return False
    return record_with_signature
