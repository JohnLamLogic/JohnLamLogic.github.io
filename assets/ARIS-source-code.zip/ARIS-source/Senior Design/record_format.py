from typing import Dict, Any, List, Tuple #specify types for readability
import json
import hashlib

#first in sequence is all 0s
GENESIS_PREV_HASH = "00" * 32

#dictionary template of one record in ARIS system
def make_record_without_signature(
    *,
    version: int, #incase the dict is updated later
    block_id: str, #serial number
    device_id: str, #id of FPGA that produced this chunk
    seq_start: int, #sequence number of first bit in block
    seq_end: int, #sequenc e number of last bit in block
    timestamp_utc: str, #UTC time when block was finalized
    bit_length: int, #how many bits ae in block
    block_hash_sha256: str, #hashed version of random data
    prev_record_hash_sha256: str, #hash of previous record
    nist: Dict[str, Any], #dict holding test results
    entropy: Dict[str, Any], #dict holding entropy estimates (might be dropped)
) -> Dict[str, Any]:
    return {
        "version": version,
        "block_id": block_id,
        "device_id": device_id,
        "seq_start": seq_start,
        "seq_end": seq_end,
        "timestamp_utc": timestamp_utc,
        "bit_length": bit_length,
        "block_hash_sha256": block_hash_sha256,
        "prev_record_hash_sha256": prev_record_hash_sha256,
        "nist": nist,
        "entropy": entropy,
    }

#turns dict into JSON string
def canonical_json_bytes(obj: Dict[str, Any]) -> bytes:
    return json.dumps(
        obj,
        sort_keys=True, #makes keys alphabetical
        separators=(",", ":"), #removes spaces
        ensure_ascii=False, #non-ascii formatting
    ).encode("utf-8")

#previous record into hash as string
def sha256_hex(data: bytes) -> str:
    h = hashlib.sha256(data).hexdigest() #hex representation of hashed data
    return h

#turns record -> JSON -> hash as string
def compute_record_hash(record_without_signature: Dict[str, Any]) -> str:
    canonical = canonical_json_bytes(record_without_signature)
    return sha256_hex(canonical)

#verify hash chain, returns true/false and message
def verify_chain(records: List[Dict[str, Any]]) -> Tuple[bool, str]:
    if not records:
        return True, "Empty list is trivially valid."
    #checking the first record's prev pointer is genesis.
    if records[0].get("prev_record_hash_sha256") != GENESIS_PREV_HASH:
        return False, "First record does not use GENESIS_PREV_HASH."
    for i in range(1, len(records)):
        prev = records[i - 1]
        curr = records[i]
        expected_prev_hash = compute_record_hash(prev)
        actual_prev_hash = curr.get("prev_record_hash_sha256")
        if actual_prev_hash != expected_prev_hash:
            return (
                False,
                f"Chain broken at index {i}: expected prev hash {expected_prev_hash}, got {actual_prev_hash}"
            )
    return True, "Chain is valid."

