import os
import sys
import json
from datetime import datetime, timezone
from typing import Dict, Any

from record_format import GENESIS_PREV_HASH, make_record_without_signature
from signing import load_private_key_pem, load_public_key_pem, sign_record
from sign_demo import verify_signed_chain
from process_entropy import (
    read_column_from_csv,
    linear_detrend,
    vn_sha_r_extract,
    nist_monobit,
    nist_runs,
    bits_to_bytes,
    sha256_hex
)

#creates a multi block chain of signed records from entropy data
def create_multi_block_chain(csv_path: str, priv_key_path: str, pub_key_path: str, bits_per_block: int = 32768):
    print(f"Loading data from {csv_path}...")
    theta = list(linear_detrend(read_column_from_csv(csv_path, "Theta")))
    r     = list(linear_detrend(read_column_from_csv(csv_path, "R")))
    
    print("Extracting entropy via vn_sha_r...")
    all_bits = vn_sha_r_extract(theta, r)
    total_bits = len(all_bits)
    print(f"Total extracted bits: {total_bits:,}")
    
    if total_bits < bits_per_block:
        print(f"Not enough bits to even make one block of size {bits_per_block}. Need more data.")
        sys.exit(1)
        
    priv = load_private_key_pem(priv_key_path)
    pub = load_public_key_pem(pub_key_path)
    
    chain = []
    prev_hash = GENESIS_PREV_HASH
    seq_start = 0
    block_num = 1
    
    print(f"\nBuilding blockchain (Block size: {bits_per_block:,} bits / {bits_per_block//8:,} bytes)...")
    
    while seq_start + bits_per_block <= total_bits:
        seq_end = seq_start + bits_per_block - 1
        chunk_bits = all_bits[seq_start:seq_end+1]
        
        #tests the chunk with nist suite
        alpha = 0.01
        mono_pass, mono_p = nist_monobit(chunk_bits, alpha)
        runs_pass, runs_p = nist_runs(chunk_bits, alpha)
        
        nist_dict: Dict[str, Any] = {
            "alpha": alpha,
            "tests": {
                "monobit": {"pass": mono_pass, "p_value": round(mono_p, 6)},
                "runs":    {"pass": runs_pass, "p_value": round(runs_p, 6)},
            },
            "all_pass": mono_pass and runs_pass,
        }
        
        if not nist_dict["all_pass"]:
            print(f"[WARN] Block {block_num} failed internal NIST checks. Skipping this chunk of entropy.")
            seq_start += bits_per_block
            continue
            
        print(f" -> Mining Block {block_num:03d} (Bits {seq_start:06d}-{seq_end:06d}) | Monobit p={mono_p:.3f}, Runs p={runs_p:.3f}")
        
        #packs and hashes the chunk
        bit_bytes = bits_to_bytes(chunk_bits)
        block_hash = sha256_hex(bit_bytes)
        
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        
        record_wo_sig = make_record_without_signature(
            version=1,
            block_id=f"block-{block_num:03d}-{block_hash[:8]}",
            device_id="ARIS-SR865-01",
            seq_start=seq_start,
            seq_end=seq_end,
            timestamp_utc=timestamp,
            bit_length=bits_per_block,
            block_hash_sha256=block_hash,
            prev_record_hash_sha256=prev_hash,
            nist=nist_dict,
            entropy={"min_entropy_est": None}
        )
        
        #signs the finished record
        signed_record = sign_record(priv, record_wo_sig)
        chain.append(signed_record)
        
        #prepares for next block in chain
        from record_format import compute_record_hash
        prev_hash = compute_record_hash(record_wo_sig)
        seq_start += bits_per_block
        block_num += 1
        
    print(f"\nSuccessfully generated a cryptographically linked chain of {len(chain)} blocks.")
    
    #saves the chain to disk as json
    out_file = "aris_chain_demo.json"
    with open(out_file, "w") as f:
        json.dump(chain, f, indent=2)
    print(f"Saved complete chain to {out_file}.")
    
    #verifies the chain ending-to-end to prove the cryptography holds
    print("\nVerifying the generated chain...")
    ok, msg = verify_signed_chain(chain, pub)
    if ok:
        print("✅ CHAIN VERIFIED: All signatures and block-hash links are perfectly valid!")
    else:
        print(f"❌ CHAIN INVALID: {msg}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--priv", required=True)
    parser.add_argument("--pub", required=True)
    parser.add_argument("--size", type=int, default=32768, help="Bits per block")
    args = parser.parse_args()
    
    create_multi_block_chain(args.csv, args.priv, args.pub, args.size)
