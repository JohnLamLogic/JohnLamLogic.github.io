#unit tests for process_entropy.py

import csv
import os
import sys
import tempfile
import unittest

#makes sure we can import from the same directory
sys.path.insert(0, os.path.dirname(__file__))

from process_entropy import (
    bits_to_bytes,
    extract_transition_bits,
    linear_detrend,
    nist_monobit,
    nist_runs,
    read_theta_from_csv,
    sha256_hex,
    von_neumann_debias,
)


#helpers

#writes a minimal sr865-style csv to a temp file and returns its path
def _write_tmp_csv(rows: list[list[str]]) -> str:
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    )
    writer = csv.writer(tmp, quoting=csv.QUOTE_ALL)
    writer.writerow(["Time", "X", "Y", "R", "Theta"])
    writer.writerows(rows)
    tmp.close()
    return tmp.name


#von neumann tests

class TestVonNeumann(unittest.TestCase):

    #perfectly alternating stream: every pair (0,1) or (1,0) is kept
    def test_balanced_alternating(self):
        bits = [0, 1] * 100   # 100 pairs → expect 100 output bits
        out = von_neumann_debias(bits)
        self.assertEqual(len(out), 100)
        ones = sum(out)
        # alternating ABABAB…: pairs are (0,1),(0,1),… → all output is 0
        self.assertEqual(ones, 0)

    def test_opposite_alternating(self):
        bits = [1, 0] * 100
        out = von_neumann_debias(bits)
        self.assertEqual(len(out), 100)
        self.assertEqual(sum(out), 100)   # all 1s

    #heavy bias means many pairs are discarded
    def test_biased_input_gives_shorter_output(self):
        bits = [1] * 190 + [0] * 10   # 95 % ones
        out = von_neumann_debias(bits)
        #at most ~5 % pairs will be (1,0) or (0,1)
        self.assertLess(len(out), 20)

    def test_identical_pairs_discarded(self):
        bits = [0, 0, 1, 1, 0, 0, 1, 1]
        out = von_neumann_debias(bits)
        self.assertEqual(out, [])   # every pair identical → nothing kept

    def test_empty_input(self):
        self.assertEqual(von_neumann_debias([]), [])

    def test_single_bit(self):
        self.assertEqual(von_neumann_debias([1]), [])


#nist monobit tests

class TestMonobit(unittest.TestCase):

    def test_balanced_passes(self):
        bits = [0, 1] * 500
        passed, p = nist_monobit(bits, alpha=0.01)
        self.assertTrue(passed)
        self.assertAlmostEqual(p, 1.0, places=3)

    def test_all_zeros_fails(self):
        bits = [0] * 1000
        passed, p = nist_monobit(bits, alpha=0.01)
        self.assertFalse(passed)
        self.assertAlmostEqual(p, 0.0, places=3)

    def test_all_ones_fails(self):
        bits = [1] * 1000
        passed, p = nist_monobit(bits, alpha=0.01)
        self.assertFalse(passed)

    def test_empty_fails(self):
        passed, p = nist_monobit([], alpha=0.01)
        self.assertFalse(passed)

    def test_slightly_biased_still_passes(self):
        # 50.1 % ones, n=100000: s_obs ~= 0.632, p ~= 0.527 >> 0.01
        bits = [1] * 50100 + [0] * 49900
        passed, p = nist_monobit(bits, alpha=0.01)
        self.assertTrue(passed, f"Expected pass but got p={p}")


#nist runs tests

class TestRuns(unittest.TestCase):

    def test_balanced_random_passes(self):
        import random
        random.seed(42)
        bits = [random.randint(0, 1) for _ in range(1000)]
        passed, p = nist_runs(bits, alpha=0.01)
        self.assertTrue(passed)

    def test_all_zeros_fails(self):
        bits = [0] * 500
        passed, _ = nist_runs(bits, alpha=0.01)
        self.assertFalse(passed)

    def test_alternating_fails(self):
        # Perfect alternation is maximally non-random — runs test must reject it
        bits = [0, 1] * 500
        passed, p = nist_runs(bits, alpha=0.01)
        self.assertFalse(passed)

    def test_too_short(self):
        passed, _ = nist_runs([0], alpha=0.01)
        self.assertFalse(passed)


#bit packing and hashing

class TestBitPacking(unittest.TestCase):

    def test_packs_correctly(self):
        bits = [1, 0, 1, 0, 1, 0, 1, 0]   # 0xAA
        b = bits_to_bytes(bits)
        self.assertEqual(len(b), 1)
        self.assertEqual(b[0], 0xAA)

    def test_truncates_to_multiple_of_8(self):
        bits = [1] * 17   # 17 bits → 16 used
        b = bits_to_bytes(bits)
        self.assertEqual(len(b), 2)

    def test_empty(self):
        self.assertEqual(bits_to_bytes([]), b"")

    def test_sha256_known(self):
        h = sha256_hex(b"")
        self.assertEqual(
            h, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        )


#csv reader tests

class TestCSVReader(unittest.TestCase):

    def setUp(self):
        self.rows = [
            ["0.0", "0.01", "-0.01", "0.014", "-45.0"],
            ["0.1", "0.01", "-0.01", "0.014", "-44.5"],
            ["0.2", "0.01", "-0.01", "0.014", "-46.0"],
        ]
        self.csv_path = _write_tmp_csv(self.rows)

    def tearDown(self):
        os.unlink(self.csv_path)

    def test_reads_theta(self):
        theta = read_theta_from_csv(self.csv_path)
        self.assertEqual(len(theta), 3)
        self.assertAlmostEqual(theta[0], -45.0)
        self.assertAlmostEqual(theta[2], -46.0)

    def test_wrong_column_raises(self):
        with self.assertRaises(ValueError):
            read_theta_from_csv(self.csv_path, theta_col="Foo")


#detrend test

class TestDetrend(unittest.TestCase):

    def test_removes_linear_trend(self):
        import numpy as np
        # Pure linear signal: after detrend the residual should be near-zero
        signal = [float(i) for i in range(100)]
        detrended = linear_detrend(signal)
        self.assertAlmostEqual(float(np.max(np.abs(detrended))), 0.0, places=8)

    def test_preserves_length(self):
        signal = [float(i) * 0.5 + 3.0 for i in range(50)]
        detrended = linear_detrend(signal)
        self.assertEqual(len(detrended), 50)


#full end-to-end pipeline test with synthetic csv

class TestFullPipeline(unittest.TestCase):
    #end-to-end test: build and sign an aris record from known-good bits,
    #then verify the signature and chain structure are correct.
    #we bypass the csv/nist path here because nist correctness is already
    #tested above; we just want to confirm that bits_to_bytes → sha-256 →
    #make_record_without_signature → sign_record → verify_signed_record
    #all wire together correctly.

    def setUp(self):
        from signing import generate_keypair_pem
        priv_pem, pub_pem = generate_keypair_pem()
        import tempfile
        self._priv_tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
        self._priv_tmp.write(priv_pem)
        self._priv_tmp.close()
        self._pub_pem = pub_pem

    def tearDown(self):
        os.unlink(self._priv_tmp.name)

    def test_signed_record_is_valid(self):
        import tempfile
        from record_format import GENESIS_PREV_HASH, make_record_without_signature, compute_record_hash
        from signing import load_private_key_pem, load_public_key_pem, sign_record, verify_signed_record
        from process_entropy import bits_to_bytes, sha256_hex
        from datetime import datetime, timezone

        # Use a known-good balanced bit stream (alternating, 128 bits)
        bits = [0, 1] * 64  # 128 bits, perfectly balanced
        bit_bytes = bits_to_bytes(bits)
        block_hash = sha256_hex(bit_bytes)

        nist_dict = {
            "alpha": 0.01,
            "tests": {
                "monobit": {"pass": True, "p_value": 1.0},
                "runs":    {"pass": True, "p_value": 0.5},
            },
            "all_pass": True,
        }

        record = make_record_without_signature(
            version=1,
            block_id="test-block-001",
            device_id="ARIS-TEST",
            seq_start=0,
            seq_end=127,
            timestamp_utc=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            bit_length=128,
            block_hash_sha256=block_hash,
            prev_record_hash_sha256=GENESIS_PREV_HASH,
            nist=nist_dict,
            entropy={"min_entropy_est": None},
        )

        priv = load_private_key_pem(self._priv_tmp.name)
        signed = sign_record(priv, record)

        # Write pub key to temp file and verify
        pub_tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
        pub_tmp.write(self._pub_pem)
        pub_tmp.close()
        try:
            pub = load_public_key_pem(pub_tmp.name)
            self.assertTrue(
                verify_signed_record(pub, signed),
                "Signature verification failed",
            )
            # Structural checks
            self.assertIn("signature", signed)
            self.assertEqual(signed["nist"]["all_pass"], True)
            self.assertEqual(len(signed["block_hash_sha256"]), 64)
            self.assertEqual(signed["bit_length"], 128)
        finally:
            os.unlink(pub_tmp.name)


if __name__ == "__main__":
    unittest.main()
